package com.sinocontact.service;

import org.apache.log4j.Logger;

public class BaseService {

	private static final Logger logger = Logger.getLogger(BaseService.class);
	public BaseService(){
		
	}
}
