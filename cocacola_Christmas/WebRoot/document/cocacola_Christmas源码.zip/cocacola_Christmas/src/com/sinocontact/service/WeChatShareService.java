package com.sinocontact.service;

import org.apache.log4j.Logger;


public class WeChatShareService extends BaseService {
	private static final Logger logger = Logger.getLogger(WeChatShareService.class);
}
